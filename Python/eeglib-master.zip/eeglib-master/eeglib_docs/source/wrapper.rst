Documentation of eeglib.wrapper module
=======================================

.. autosummary::

.. automodule:: eeglib.wrapper
    :members:
    :undoc-members:
