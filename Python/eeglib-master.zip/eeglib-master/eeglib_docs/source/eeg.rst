Documentation of eeglib.eeg module
==================================

.. automodule:: eeglib.eeg
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
